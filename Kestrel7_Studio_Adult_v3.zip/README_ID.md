# Kestrel-7 Studio v2

Proyek awal Android + backend untuk alur virtual try-on / edit gambar AI.

## Isi
- Android native Java: pilih foto, tulis instruksi, tombol Proses Gambar, status, pratinjau, simpan hasil.
- Backend FastAPI: menerima gambar dan instruksi, meneruskan ke OpenAI Images API.
- API key hanya disimpan di server melalui environment variable `OPENAI_API_KEY`.

## Penting
Aplikasi ini belum bisa mengedit gambar sebelum backend dijalankan dan `OPENAI_API_KEY` disetel.
Jangan pernah menaruh API key di aplikasi Android atau mengunggahnya ke GitHub.

## Jalankan backend lokal
Python 3.10+:
```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
# set OPENAI_API_KEY sebagai environment variable
uvicorn main:app --host 0.0.0.0 --port 8000
```
Untuk penggunaan dari internet/HP, deploy backend ke layanan hosting HTTPS, lalu isi `API_BASE_URL` di `android/app/src/main/java/com/kestrel7/studio/MainActivity.java`.
Jangan gunakan alamat localhost dari HP untuk mengakses backend di komputer.

## Build APK
Buka folder `android` di Android Studio, tunggu Gradle sync, lalu Build > Build Bundle(s) / APK(s) > Build APK(s).
Atau gunakan GitHub Actions setelah mengunggah isi proyek ini ke repository.


## Mode Adult Creative (v3)
Versi ini menambahkan konfirmasi usia 18+ dan pilihan kategori kreatif dewasa (fashion editorial, swimwear/lingerie, artistic portrait, adult creative). Ini adalah deklarasi pengguna, bukan verifikasi identitas/usia yang kuat.

**Batas layanan AI:** UI aplikasi tidak dapat menghapus moderasi atau kebijakan penyedia model. Jika memakai OpenAI API, permintaan tetap tunduk pada kebijakan OpenAI dan dapat ditolak. Jangan memasarkan aplikasi sebagai alat untuk membuat semua jenis konten tanpa batas. Gunakan hanya gambar orang dewasa yang memberi persetujuan, dan patuhi hukum setempat.

Backend tetap memerlukan `OPENAI_API_KEY` yang disetel sebagai secret/environment variable di server. API key jangan dimasukkan ke APK atau GitHub.
