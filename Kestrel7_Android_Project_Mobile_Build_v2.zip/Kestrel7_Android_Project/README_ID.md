# Kestrel-7 Studio — proyek Android

## Fitur pada versi awal
- Aplikasi Android native sederhana.
- Memilih foto dari HP.
- Menulis instruksi pengeditan.
- Menyiapkan APK debug melalui GitHub Actions.

## Batasan penting
Versi ini adalah prototipe UI. Fitur menghasilkan gambar dengan AI belum diaktifkan. Untuk AI sungguhan, perlu backend/server yang aman dan API key yang tidak ditanam di aplikasi Android atau di repositori publik.

## Build APK dari GitHub lewat HP
1. Unggah semua isi folder proyek ini ke root repositori GitHub, termasuk folder tersembunyi `.github` dan `app`.
2. Buka tab Actions.
3. Pilih "Build Kestrel-7 APK" lalu "Run workflow".
4. Setelah sukses, buka hasil workflow dan unduh artifact `Kestrel7-APK`.
5. Ekstrak ZIP artifact dan pasang `app-debug.apk`.
